<!DOCTYPE html>
<html>
<head>
	<title>Halaman beranda</title>
	<style type="text/css">
		ul {  
			list-style-type: none;  
		}
		a:link { text-decoration: none; }
	</style>
</head>
<body style="background-color:#FAEBD7">
<body >
	<table  width="100%">
		<tr>
		<ul><li style="list-style-type:none;">
			<li><center>
				<h1>WELCOME TO DURI PRIDE</h1>
			</center>
			</li>
				</div>

		</tr>
			<td width="25%">
			<b><u>MENU KIRI</u></b><br>
			<ul>
				<li>
					<a href="lihat_pengguna.php">Lihat Pengguna</a>
				</li>
				<li>
					<a href="tambah_pengguna.php">Tambah Pengguna</a>
				</li>
				<li>
					<a href="hapus.php">Hapus Pengguna</a>
				</li>
				<li>
					<a href="update_data.php">Edit Pengguna</a>
				</li>
			</ul>
			</td>
			<td>
	<b>FORM TAMBAH DATA</b>
	<form action="proses_tambah_data.php" method="POST">
	<table border="1">
		<tr>
			<td>
				NAMA
			</td>
			<td>
				<INPUT name="nama_pengguna" TYPE="TEXT" PLACEHOLDER="nama anda">
			</td>
		</tr>
		<tr>
			<td>
				SANDI
			</td>
			<td>
				<INPUT name="sandi_pengguna" TYPE="PASSWORD" PLACEHOLDER="password anda">
			</td>
		</tr>
		<tr>
			
			<td>
				<INPUT  TYPE="submit" value="Kirim Data">
			</td>
		</tr>
	</table>
	</form>
</body>
</html>