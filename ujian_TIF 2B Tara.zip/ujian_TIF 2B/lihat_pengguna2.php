<!DOCTYPE html>
<html>
<head>
	<title>Halaman beranda</title>
	<style type="text/css">
		ul {  
			list-style-type: none;  
		}
		a:link { text-decoration: none; }
	</style>
</head>
<body style="background-color:#B0C4DE;">
<body >
	<table  width="100%">
		<tr>
		<ul><li style="list-style-type:none;">
			<li><center>
				<h1>WELCOME TO DURI PRIDE</h1>
			</center>
			</li>
				</div>

		</tr>
			<td width="25%">
			<b><u>MENU KIRI</u></b><br>
			<ul>
				<li>
					<a href="lihat_pengguna.php">Lihat Pengguna</a>
				</li>
				<li>
					<a href="tambah_pengguna.php">Tambah Pengguna</a>
				</li>
				<li>
					<a href="hapus.php">Hapus Pengguna</a>
				</li>
				<li>
					<a href="lihat_pengguna3.php">Edit Pengguna</a>
				</li>
			</ul>
			</td>
			<td>
			<b><u>LIST PENGGUNA</u></b><br>
			<?php 
				include "koneksi.php";
				$kueri=mysqli_query($konek,'SELECT * FROM tb_pengguna');
				?>
				<table border="1">

				<tr>
					
					<td>
						<b>
						NO
					</b>
					</td>
					<td>
						<b>
						Nama Pengguna
					</b>
					</td>
					<td>
						<b>
						Sandi Pengguna
						</b>
						</td>
						<td>
							<b>
							Aksi
							</b>
						</td>
					</tr>

		<?php
				while($row = mysqli_fetch_array($kueri)){
					echo"<tr><td>";
					echo $row['id_pengguna'];
					echo"</td><td>";
					echo $row['nama_pengguna'];
					echo"</td><td>";
					echo $row['sandi_pengguna'];
					echo"</td>
					<td>";
					echo"
						<a href='hapus.php?apanih=".$row['nama_pengguna']."		'>hapus</a>
					";
				}
			?>
			</table>
			<br>
			</td>
		</tr>
	</table>
</body>
</html>