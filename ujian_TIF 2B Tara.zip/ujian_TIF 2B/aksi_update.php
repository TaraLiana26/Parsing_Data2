<?php 
include "koneksi.php";
$nama=$_POST['nama'];
$password=$_POST['boleeeh'];
$query="UPDATE tb_pengguna SET nama_pengguna='$nama' WHERE sandi_pengguna='$password'";
header("location:lihat_pengguna.php");