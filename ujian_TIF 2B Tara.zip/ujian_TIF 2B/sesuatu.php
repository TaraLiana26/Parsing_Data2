<?php
/**
 * [$nomer_penduduk description]
 * VARIABEL INI BERASAL DARI INDEX.HTML
 * digunakan untuk menampung data nomer induk kependudukan
 * 18-01-2023 slamet
 * edited 20-01-2023 slamet
 * @var [type]
 */
$nomer_penduduk=$_POST["tara_liana"];
$nama_kamu=$_POST["nama"];
$alamat=$_POST["boleeeh"];
echo "$nomer_penduduk $nama_kamu $alamat";