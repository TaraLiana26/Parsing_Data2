<?php 
$nama=$_GET['apanih'];
$sandi=$_GET['sandi'];
include "koneksi.php";
mysqli_query($konek,'INSERT FROM tb_pengguna WHERE nama_pengguna="'.$id.'"');
header("location:lihat_pengguna3.php");